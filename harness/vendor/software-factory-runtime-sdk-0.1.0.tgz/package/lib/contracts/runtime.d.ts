/** Run API 1.0. JSON-only types shared by the backend, SDK and future UI. */
export type RunJson = null | boolean | number | string | RunJson[] | {
    [key: string]: RunJson;
};
export type RunObject = {
    [key: string]: RunJson;
};
export type RunStatus = 'queued' | 'running' | 'cancelling' | 'completed' | 'failed' | 'cancelled' | 'interrupted';
export type ReportStatus = 'running' | 'completed' | 'failed' | 'cancelled';
export interface ModelRef {
    provider: string;
    model: string;
}
export interface RunRequest {
    toolId: string;
    input: RunObject;
    model?: ModelRef;
    timeoutMs?: number;
}
export interface ToolContract {
    toolId: string;
    description: string;
    inputSchema: RunObject;
    supportsRun: boolean;
}
export interface ProgressReport {
    stage: string;
    stageName: string;
    progress?: number;
    message?: string;
}
export interface IssueReport {
    level: 'warning' | 'error';
    stage?: string;
    code?: string;
    message: string;
    fatal?: boolean;
}
export interface LogRecord {
    message: string;
    stage?: string;
    time: string;
}
export interface IssueRecord extends IssueReport {
    time: string;
}
export interface ArtifactInput {
    kind: 'intermediate' | 'final';
    name: string;
    relativePath: string;
    mime: string;
}
export interface Artifact extends ArtifactInput {
    artifactId: string;
    size: number;
    downloadUrl?: string;
}
export interface BusinessResult {
    text?: string;
    files?: string[];
}
export interface RunResult {
    text?: string;
    files: Artifact[];
}
/** API-style image input; URLs are public HTTP(S) or base64 image data URLs. */
export interface ModelTextPart {
    type: 'text';
    text: string;
}
export interface ModelImagePart {
    type: 'image_url';
    image_url: {
        url: string;
    };
}
export type ModelUserContent = string | Array<ModelTextPart | ModelImagePart>;
export type ModelMessage = {
    role: 'system' | 'assistant';
    content: string;
} | {
    role: 'user';
    content: ModelUserContent;
};
export interface ModelRequest {
    messages: ModelMessage[];
}
/** DSH usage: inputTokens excludes cache; preserve the optional cache counters. */
export interface ModelUsage {
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens?: number;
    cacheWriteTokens?: number;
    totalTokens?: number;
    reasoningTokens?: number;
}
export interface ModelResponse {
    text: string;
    usage?: ModelUsage;
}
export interface RunSummary {
    runId: string;
    toolId: string;
    status: RunStatus;
    stage?: string;
    stageName?: string;
    progress?: number;
    message?: string;
    createdAt: string;
    startedAt?: string;
    finishedAt?: string;
}
export interface RunRecord extends RunSummary {
    apiVersion: '1.0';
    model?: ModelRef;
    logs: LogRecord[];
    issues: IssueRecord[];
    artifacts: Artifact[];
    result?: RunResult;
    lastSeq: number;
}
export interface ListRunsRequest {
    toolId?: string;
    status?: RunStatus;
    limit?: number;
    offset?: number;
}
export interface RunIdRequest {
    runId: string;
}
export interface ArtifactRequest extends RunIdRequest {
    artifactId: string;
}
export interface ToolContractRequest {
    toolId: string;
}
export interface WaitRunRequest extends RunIdRequest {
    afterSeq?: number;
    waitMs?: number;
}
export interface WatchRunRequest extends RunIdRequest {
    afterSeq?: number;
}
export interface RunEvent {
    runId: string;
    seq: number;
    type: 'status' | 'progress' | 'log' | 'issue' | 'artifact' | 'result';
    data: RunJson;
    time: string;
}
export interface RunAccepted {
    runId: string;
    status: 'queued';
}
export interface RunList {
    items: RunSummary[];
    total: number;
}
export interface RunUpdate {
    run: RunSummary;
    events: RunEvent[];
    lastSeq: number;
}
export interface CancelResult {
    runId: string;
    status: RunStatus;
}
export interface RuntimeFailure {
    code: string;
    message: string;
}
export type RuntimeResult<T> = {
    ok: true;
    data: T;
} | {
    ok: false;
    error: RuntimeFailure;
};
