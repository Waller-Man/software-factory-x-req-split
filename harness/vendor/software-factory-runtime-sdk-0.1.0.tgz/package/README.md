# 软件工厂 Run SDK 接入指南

适用：Runtime SDK 0.1.0、DSH 0.2.1-alpha.2、Node.js 24+。

本指南供开发者或开发助手将已有算法接入 Run。按“确认输入输出 → 导入 SDK → 登记入口 → 接入上报 → 调试 → 交付插件”执行，后续可据此整理成 Skill。

**代码块中的业务实现均为 TS 风格伪代码，不是可以直接复制运行的完整工程。** SDK 导入路径、接口名、参数名和返回格式保持真实；“你的算法”“保存文件”“调用DSHTool”等表示需要实现或对接的步骤，不是 SDK 导出函数。

## 1. 接入前确认

先从业务项目中确定以下信息；已有说明能回答时直接沿用：

| 信息 | 需要确定什么 |
| --- | --- |
| 入口 | 本次接入哪个业务函数，对外 toolId 是什么 |
| 输入 | 实际参数名称、类型、必填项及一个小输入示例 |
| 输出 | 最终交付文本、文件或两者；哪些材料需要保留为中间产物 |
| 模型 | 算法是否需要模型；不需要时不要增加必填模型参数 |
| 取消 | 如何停止算法及清理自己创建的连接、进程等资源 |
| 环境 | DSH 服务端能否运行算法，需要哪些真实依赖 |

接入目标是**可安装、可启用、支持 DSH 网页版调用的 Host 插件**。业务算法在服务端运行，网页负责发起调用和查看结果；当前使用原生网页聊天，独立 Run 执行页尚未开发。

推荐按职责分文件，沿用现有工程也可以：

```text
my-plugin/
├── src/index.ts          # DSH 插件入口、SDK 登记
├── src/business.ts       # 调用你的算法、统一上报
├── scripts/debug.ts     # 本地调试入口
├── python/              # 可选：已有 Python 算法
├── vendor/              # 平台交付的 SDK TGZ
├── .env              # 所需要的第三方配置
└── README.md            # 本业务的调用、启动及依赖说明
```

## 2. 导入 SDK

在已有 DSH 插件工程中，将 SDK TGZ 放入 vendor/，执行：

```powershell
npm.cmd install ./vendor/software-factory-runtime-sdk-0.1.0.tgz
```

导入方式：

```ts
import { registerRunTool } from '@software-factory/runtime-sdk';
import type { ExecutionContext, BusinessResult } from '@software-factory/runtime-sdk';
```

平台需已启用 Runtime；DSH 及 Cordis／Tools 依赖使用项目匹配的宿主开发环境。安装 SDK 不会安装或启动 DSH，也不假定 SDK 已发布到公共 npm。

## 3. 按这个流程接入你的代码

### 3.1 业务函数：接收参数、运行算法、交回结果

```ts
// 伪代码：src/business.ts
async function runBusiness(input, execution): Promise<BusinessResult> {
  execution.signal.throwIfAborted();
  await execution.log('开始处理', 'process');
  await execution.reportProgress({
    stage: 'process', stageName: '业务处理', progress: 20
  });

  // 在这里运行你的算法，input 是调用者传入的实际业务参数。
  let result = await 你的算法(input);

  // 可选：只有算法确实需要时才调用模型。
  if (业务需要模型) {
    const answer = await execution.model.call({
      messages: [{ role: 'user', content: 待处理文本 }]
    });
    result = 根据模型回答继续处理(result, answer.text);
  }

  execution.signal.throwIfAborted();
  // 可选：有中间材料时，保存到任务目录，再登记。
  保存文件(execution.outputDirectory, 'intermediate/material.json', 中间材料);
  await execution.addArtifact({
    kind: 'intermediate', name: '中间材料',
    relativePath: 'intermediate/material.json', mime: 'application/json'
  });

  保存文件(execution.outputDirectory, 'final/result.txt', result.text);
  const file = await execution.addArtifact({
    kind: 'final', name: '结果.txt',
    relativePath: 'final/result.txt', mime: 'text/plain'
  });
  return { text: result.text, files: [file.artifactId] };
}
```

只交付文本时返回 `{text:结果文本}`；只交付文件时返回 `{files:[file.artifactId]}`。不要求每个业务都生成示例中的文件或使用模型。至少交付非空文本或一个文件。

### 3.2 插件启用时登记业务入口

```ts
// 伪代码：src/index.ts；省略业务类型和具体 Schema 的展开。
export const inject = ['tools', 'sfRuntime'];

export function apply(ctx) {
  registerRunTool(ctx, {
    toolId: 'sf_your_tool',
    description: '说明你的算法做什么、接受什么、交付什么',
    inputSchema: 你的实际对象JSONSchema,
    execute: runBusiness
  });
}
```

inputSchema 必须与真实函数参数一致，例如业务接受 text，就声明 text，不能只根据数据库中的能力描述猜测参数。

登记发生在插件启用时；Run 启动每个任务时才执行 `runBusiness(input, execution)`。registerRunTool 封装了正常 DSH Tool 登记与 Run 协议接入，不办理 HugeGraph Agent 入库。

按原有 DSH 插件工程方式构建和打包，保证有效入口、bundle patch、显示信息和必要算法文件齐全。具体安装规范使用 cordis-plugin-development Skill，不在此展开工程配置。

## 4. 下层接口：业务函数向 Run 上报

下层共 9 项：登记函数、execute 回调和 7 个 execution 方法。以下各节独立说明用途、参数、返回值与伪代码。异步调用均应 await。

### 4.1 registerRunTool(ctx, definition)

用途：把业务函数登记为 DSH Tool，同时接入 Run。

| 参数 | 必填 | 含义 |
| --- | --- | --- |
| ctx | 是 | DSH 传给插件 apply 的 Context |
| definition.toolId | 是 | 唯一业务 Tool 名称 |
| definition.description | 是 | 功能说明 |
| definition.inputSchema | 是 | 实际参数的对象 JSON Schema |
| definition.execute | 是 | 本次任务执行时调用的业务函数 |

用法见 3.2。返回异步释放函数 `() => Promise<void>`，通常由 SDK 绑定的插件生命周期管理。

### 4.2 execute(input, execution)

用途：接收业务输入，运行你的代码，返回最终结果。

| 输入／输出 | 说明 |
| --- | --- |
| input | 与 inputSchema 一致的只读业务参数 |
| execution | Run 自动提供的本次任务上下文，不由调用者填写 |
| 返回值 | `Promise<{text?:string,files?:string[]}>`，files 为已登记的 final 文件 ID |

```ts
// 伪代码：最小业务回调。
async function execute(input, execution) {
  const result = await 你的算法(input);
  return { text: result.text };
}
```

上下文属性：

| 属性 | 用法 |
| --- | --- |
| execution.runId | 本次任务唯一 ID |
| execution.outputDirectory | 本次任务产物根目录 |
| execution.signal | 取消信号；调用 throwIfAborted() 检查是否应停止 |
| execution.model.selection | 本次固定的 `{provider,model}`，也可能没有值 |

正常返回并完成结果校验后，Run 标为 completed。直接抛出带具体原因的错误，Run 会记录并进入失败处理。

### 4.3 reportStatus(status, message?)

用途：上报任务状态。返回 `Promise<void>`。

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| status | 是 | running、completed、failed、cancelled |
| message | 否 | 状态说明 |

```ts
await execution.reportStatus('running', '开始处理输入');
```

开始和完成通常由 Run 自动管理。上报 completed 不会提前结束函数，实际完成以返回结果为准；failed／cancelled 会触发停止流程，业务仍需配合 signal 停止。只做取消，没有暂停。

### 4.4 reportProgress(report)

用途：上报阶段和百分比。返回 `Promise<void>`。

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| stage | 是 | 阶段标识，如 parse |
| stageName | 是 | 展示名称，如“解析输入” |
| progress | 否 | 0～100 的任务百分比 |
| message | 否 | 当前处理说明 |

```ts
await execution.reportProgress({
  stage: 'parse', stageName: '解析输入', progress: 30,
  message: '已处理部分输入'
});
```

不知道百分比时只报阶段和说明。

### 4.5 log(message, stage?)

用途：保存执行消息，供上层查看。返回 `Promise<void>`。

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| message | 是 | 日志文本 |
| stage | 否 | 所属阶段标识 |

```ts
await execution.log('输入解析完成', 'parse');
```

console.log 用于本地或服务端终端调试；需要进入任务记录的消息使用 execution.log。

### 4.6 reportIssue(issue)

用途：记录告警、错误及原因。返回 `Promise<void>`。

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| level | 是 | warning 或 error |
| message | 是 | 具体原因 |
| stage | 否 | 所属阶段 |
| code | 否 | 业务错误码 |
| fatal | 否 | true 表示停止任务；省略时只记录 |

```ts
// 可继续的告警。
await execution.reportIssue({
  level: 'warning', stage: 'parse', message: '部分空白内容已跳过'
});

// 必须停止。
await execution.reportIssue({
  level: 'error', stage: 'parse', message: '没有可处理的内容', fatal: true
});
execution.signal.throwIfAborted();
```

error 级别本身不会停止任务，由 fatal 决定。简单失败也可直接 `throw new Error('具体原因')`。

### 4.7 addArtifact(file)

用途：登记已经保存的中间材料或最终文件。返回 `Promise<Artifact>`。

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| kind | 是 | intermediate 或 final |
| name | 是 | 文件展示名称 |
| relativePath | 是 | 相对 execution.outputDirectory 的路径 |
| mime | 是 | 文件媒体类型 |

```ts
// 伪代码：先保存，再登记，最后返回文件 ID。
保存文件(execution.outputDirectory, 'final/report.md', 报告内容);
const file = await execution.addArtifact({
  kind: 'final', name: '报告.md',
  relativePath: 'final/report.md', mime: 'text/markdown'
});
return { files: [file.artifactId] };
```

Artifact 包含 artifactId、kind、name、relativePath、mime、size。中间材料放 intermediate/ 或 snapshots/，最终文件放 final/，这些目录由 Run 创建。新增深层目录自行创建。

addArtifact 不生成或复制文件；最终返回的是已登记的 final 文件 ID，不是路径。认证下载引用交给上层获取。

### 4.8 model.call(request)

用途：调用本次任务固定的 DSH 模型。返回 `Promise<{text,usage?}>`。

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| messages | 是 | 至少一条消息 |
| messages[].role | 是 | system、user 或 assistant |
| messages[].content | 是 | 文本字符串；user 消息也支持文本／图片内容块数组 |
| content[].type | 数组时是 | text 或 image_url |
| content[].text | text 时是 | 文本内容 |
| content[].image_url.url | image_url 时是 | 公网 HTTP(S) 图片地址，或 data:image/...;base64,... |

```ts
const answer = await execution.model.call({
  messages: [
    { role: 'system', content: '请提取需求要点。' },
    { role: 'user', content: input.text }
  ]
});
// 伪代码：使用回答继续你的算法。
const result = 根据模型回答继续处理(answer.text);
```

图片解析仍通过同一个 call，风格与开发者直接调用模型 API 相似：

```ts
// TS 风格伪代码：图片地址来自你的业务输入。
const answer = await execution.model.call({
  messages: [
    { role: 'system', content: '请提取需求截图中的要点。' },
    {
      role: 'user',
      content: [
        { type: 'text', text: '分析以下图片' },
        { type: 'image_url', image_url: { url: 图片URL或Base64DataURL } }
        // 多图：继续添加 image_url 内容块。
      ]
    }
  ]
});
const result = 根据模型回答继续处理(answer.text);
```

本地图片先由业务代码读取，再拼成 `data:image/png;base64,...` 等 Data URL；不要直接填本机文件路径。支持 PNG、JPEG、GIF、WebP，图片由 DSH 附件服务校验、保存，再交给任务选定的视觉模型解析。公网 URL 由服务端匿名获取，遵循宿主代理设置，拒绝本地／私有网络地址，受取消信号和附件大小限制约束；需要登录的图片应由业务代码按自身权限读取后传 Base64。

图片只放在 user 消息；system 和 assistant 保持文本。不新增 files 上传接口，不接受厂商 file_id；PDF、Word 等普通文件仍需业务代码先解析成文本或图片。当前只开放上表字段，不是完整厂商 SDK 的参数透传。

text 是模型对文本或图片的回答；usage 是可选 token 用量及缓存计数。纯算法不需要调用此接口。

启动任务时 model 可选：省略则使用来源会话已有模型；传入则固定指定 provider/model。没有可用模型却调用 model.call 会报 MODEL_REQUIRED。不传 API Key，不在每次模型请求中换路由。调用使用隔离模型会话，多轮所需历史由 messages 显式传入。

```ts
// TS 风格伪代码：手动多轮；messages 保留上一轮传入的图文内容。
messages.push({ role: 'assistant', content: answer.text });
messages.push({ role: 'user', content: '把上面的要点整理成表格' });
const next = await execution.model.call({ messages });
```

所选模型须在 DSH 实际路由元数据中声明支持 image，否则报 MODEL_IMAGE_UNSUPPORTED，不悄悄忽略图片。未启用附件服务时报 IMAGE_SERVICE_UNAVAILABLE。文本总量限制仍为 1 MiB；图片按 DSH 附件限制及模型实际能力处理，不占用这个文本限额。模型日志保存附件引用，不重复写入图片 Base64。

### 4.9 registerCleanup(callback)

用途：登记任务完成、失败、取消等结束流程的资源清理。返回 void；callback 可返回 void 或 Promise<void>。

```ts
// 伪代码：resource 是你的连接、进程或后台任务。
const resource = 创建你的资源();
execution.registerCleanup(async () => {
  await 停止并等待资源退出(resource);
});

for (const item of 待处理数据) {
  execution.signal.throwIfAborted();
  await 处理一项(item);
}
```

只清理自己创建的资源。耗时算法应定期检查 signal；持续占用线程的同步计算需要分段或放进可停止的工作线程／子进程。

## 5. 上层接口：如何传参启动和查看任务

下层是你的函数向 Run 上报；上层是网页、编排或其他调用者向 Run 发起请求。上层接口**不是从本 SDK 导入的 JS 函数**。

| 用途 | DSH Tool／Remote | request 输入 | data 输出 |
| --- | --- | --- | --- |
| 查看输入规格 | sf_runtime_get_tool_contract／getToolContract | `{toolId}` | toolId、description、inputSchema、supportsRun |
| 启动 | sf_runtime_run_tool／runTool | `{toolId,input,model?,timeoutMs?}` | `{runId,status:'queued'}` |
| 查询 | sf_runtime_get_run／getRun | `{runId}` | 状态、阶段、进度、logs、issues、artifacts、result、lastSeq 等 |
| 列表 | sf_runtime_list_runs／listRuns | `{toolId?,status?,limit?,offset?}` | `{items,total}` |
| 等待更新 | sf_runtime_wait_run／waitRun | `{runId,afterSeq?,waitMs?}` | `{run,events,lastSeq}` |
| 取消 | sf_runtime_cancel_run／cancelRun | `{runId}` | `{runId,status}` |
| 持续订阅 | 仅 Remote：watchRun | `{runId,afterSeq?}` | RunEvent 流：runId、seq、type、data、time |
| 获取文件 | sf_runtime_get_artifact／getArtifact | `{runId,artifactId}` | 文件元数据和认证 downloadUrl |

服务返回 `{ok:true,data}` 或 `{ok:false,error:{code,message}}`。Remote 使用已有 DSH 认证连接、sfRuntime 命名空间及真实 runtimeSessionId，外层还有标准 RemoteResult；接线见 [接口规范](docs/runtime-api.md)。不要自行假定存在公共 HTTP 地址。

调用流程伪代码：

```ts
// 调用DSHTool 代表宿主正常 Tool 调用链，不是 SDK 导出函数。
const accepted = await 调用DSHTool('sf_runtime_run_tool', {
  toolId: 'sf_your_tool',
  input: { text: '一段示例输入' }
  // 可选：model: { provider: 实际providerID, model: 实际modelID }
  // 可选：timeoutMs: 120000
});
检查服务返回ok(accepted);
const runId = accepted.data.runId;

const update = await 调用DSHTool('sf_runtime_wait_run', { runId, waitMs: 15000 });
const record = await 调用DSHTool('sf_runtime_get_run', { runId });
// 从 record.data.result 取得最终文本和文件。
// 需要停止时：调用 sf_runtime_cancel_run，参数 { runId }。
```

input 按实际 Schema 填写；model、timeoutMs 位于启动请求顶层。waitRun 每次最多等待 30 秒，等待到期不会取消任务；继续等待时传上次 lastSeq 为 afterSeq。文件从 getRun 返回的结果中取得真实 artifactId，再用 getArtifact 获取下载引用。

## 6. 快速启动与调试步骤

### 6.1 本地先调业务，不启动 DSH

```ts
// 伪代码：先验证算法本身。
const input = 一个小规模输入;
const result = await 你的算法(input);
打印并检查(result);

// 再验证 SDK 接入，调试上下文由你在 scripts/debug.ts 中创建。
const execution = 创建本地调试上下文({
  日志和进度: 打印到终端,
  产物目录: 本项目临时目录,
  文件登记: 检查文件存在并返回模拟artifactId,
  模型调用: 本地先不调用真实模型
});
const output = await runBusiness(input, execution);
检查文本和文件(output);
```

“创建本地调试上下文”不是 SDK 方法。替身按 ExecutionContext 实现即可，不需要做完整测试框架；它不代表真实 Tool 注册、权限或下载认证已经通过。

补齐真实实现和调试入口后，Node.js 24 可从项目根目录运行：

```powershell
node --experimental-strip-types scripts/debug.ts
```

需要断点时，使用 VS Code 的 JavaScript Debug Terminal；或执行以下命令后附加 Node 调试器：

```powershell
node --inspect-brk --experimental-strip-types scripts/debug.ts
```

在业务函数入口、算法调用、模型调用和文件返回处打断点，观察 input、execution.outputDirectory 和结果。以上命令需要真实代码，不能直接运行本指南中的占位伪代码。

### 6.2 在 DSH 网页验证完整调用

1. 按项目原有方式构建，将业务插件通过 DSH 插件管理安装到当前网页版使用的 profile；先启用 Runtime，再启用业务插件。
2. 在 Runtime 原生配置 allowedToolIds 中加入你的 toolId，保留已有项。
3. 打开 DSH 网页，进入绑定真实工作区的聊天。平台尚未启动时，本地 DSH 源码目录可执行 `pnpm.cmd dsh web --no-open`；默认地址 http://127.0.0.1:3080，已有部署使用实际地址。
4. 要求正常调用 sf_runtime_get_tool_contract，确认真实输入；再通过 sf_runtime_run_tool 传入小规模业务参数。
5. 用 waitRun／getRun 检查日志、阶段、进度和最终结果，用 getArtifact 验证文件引用。
6. 对一个稍长的小任务验证取消，确认算法停止且自有资源退出。

修改代码后重新构建并按宿主更新流程加载；若提示 restart-required，按要求重启。刷新网页不能证明后端代码已更新。浏览器本机路径也不能当成服务端文件路径。

### 6.3 调试时看哪里

| 内容 | 位置 |
| --- | --- |
| 算法局部变量、堆栈 | 本地断点或 DSH 服务端终端 |
| SDK 日志和问题 | getRun 的 data.logs、data.issues |
| 启动输入 | `<workspace>/outputs/runs/<runId>/input/request.json` |
| 状态与事件记录 | 同一任务目录的 run.json，内容为 record、events |
| 中间材料、快照、最终文件 | 同一任务目录的 intermediate/、snapshots/、final/ |

| 现象 | 优先检查 |
| --- | --- |
| 找不到 Tool／无权限 | 插件启用结果、toolId、Runtime 允许项、宿主权限 |
| RUNTIME_CONTEXT_REQUIRED | 是否绕过 Run 直接调用了业务 Tool |
| 参数失败 | input 是否符合真实 inputSchema |
| MODEL_REQUIRED | 是否没有可用模型却调用了 model.call |
| MODEL_IMAGE_UNSUPPORTED | 本次 provider/model 是否在 DSH 中声明支持图片 |
| IMAGE_SERVICE_UNAVAILABLE | DSH 附件服务是否已启用 |
| 图片被拒绝 | URL 是否公网可访问；Base64 格式、真实图片类型、大小是否符合 DSH 附件限制 |
| 文件无效 | 是否先保存再登记，返回的是否是当前任务 final 文件 ID |
| 取消后继续运行 | 是否检查 signal，并清理自己的进程或其他资源 |

只需小输入验证主要流程；不默认运行完整真实算法或消耗真实模型额度。

## 7. Python 项目接入原则

链路为：DSH 网页 → Run → TS 业务入口 → Python 算法。仍需交付 DSH 插件；Python 不直接导入 TS SDK，TS 负责统一上报和返回。

```ts
// TS 风格伪代码：描述适配职责，不限定业务自己的通信实现。
async function runPythonBusiness(input, execution) {
  execution.signal.throwIfAborted();
  await execution.reportProgress({ stage: 'python', stageName: 'Python处理' });

  const job = 启动Python算法({
    interpreter: 服务端实际解释器路径,
    script: 服务端实际脚本路径,
    input,
    outputDirectory: execution.outputDirectory,
    signal: execution.signal
  });
  execution.registerCleanup(async () => {
    await 停止并等待自有Python进程退出(job);
  });

  // 需要内部进度时，在适配层将 Python 消息转交给 SDK。
  转发阶段和日志(job, execution.reportProgress, execution.log);
  const result = await 等待Python结果(job);
  execution.signal.throwIfAborted();

  // Python 已把文件保存到本任务的 final/ 下。
  const file = await execution.addArtifact({
    kind: 'final', name: result.name,
    relativePath: result.relativePath, mime: result.mime
  });
  return { text: result.text, files: [file.artifactId] };
}
```

“启动Python算法”等由开发者的适配层实现，SDK 没有内置通用 Python 桥。简单调用可采用 JSON 输入输出；需要逐步进度时再约定消息格式，算法日志与结果应能区分。

Python 依赖在部署准备阶段安装，运行任务时不自动安装。调试顺序为：单独调 Python 函数 → 验证输入输出 → 用 TS 调试入口调用 → 在 DSH 网页调用。需要模型时优先由 TS 使用 model.call，将必要结果传给 Python，不传模型 API Key。

## 8. 完成标准与推荐 Skill

接入完成时确认：

- 已交付可安装并启用的 DSH Host 插件，网页能通过 Run 启动真实业务入口。
- 实际输入和 inputSchema 一致，上报接口遵守本指南的字段与含义。
- 能读取进度、日志和结果；有文件时先保存、再登记，交付 final 文件 ID。
- 模型按需调用、启动字段可选；取消能停止业务并清理自有资源。
- 业务 README 写明真实输入输出、快速启动、运行依赖、模型选择、产物位置及升级方法。
- 交付说明区分本地调试、真实宿主验证和真实模型运行；未做的如实标注。

推荐使用 brainstorming 明确小范围方案；用 cordis-plugin-development 处理插件工程、安装与宿主规范。仅在业务需要处理 Word／PDF／表格时，再使用对应文档 Skill。

后续转换为 Skill 时，可将第 1 节作为输入信息，第 2～7 节作为执行步骤和接口参考，第 8 节作为完成标准；依据实际项目填入业务入口与参数，避免把示例工具名和占位步骤固定成实现。
